# dockerhubimages
1.  Create the image 
2.  Publish the image to docker hub
3.  Github actions
